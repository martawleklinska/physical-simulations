import taskmanager

tm = taskmanager.TaskManager()

tm.task1()
# tm.task2()
# tm.task3()
# tm.task4()
# tm.task5()
